﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CategoriesSubCategories.Models;

namespace CategoriesSubCategories.ViewModels
{
    public class CategoryLevelCollection
    {
        public virtual Category Category { get; set; }

        public virtual int CategoryLevel { get; set; }
    }

    public class CategoryLevel
    {
        public virtual ICollection<CategoryLevelCollection> CategoryLevelCollections { get; set; }
    }
}